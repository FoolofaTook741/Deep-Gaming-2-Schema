AddCSLuaFile( "cl_init.lua" ) -- Make sure clientside
AddCSLuaFile( "shared.lua" )  -- and shared scripts are sent.
 
include('shared.lua')
 
function ENT:Initialize()
	self:SetModel( "models/props_lab/blastdoor001a.mdl" )
	self:PhysicsInit( SOLID_VPHYSICS )      -- Make us work with physics,
	self:SetMoveType( MOVETYPE_VPHYSICS )   -- after all, gmod is a physics
	self:SetSolid( SOLID_VPHYSICS )         -- Toolbox
	self.NextTP = 0
    local phys = self:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:Wake()
	end
end


function ENT:Use( activator, caller )
	if activator:IsCP() or activator:Team() == TEAM_ZOMBIE then return end
	if CurTime() > self.NextTP or CurTime() > activator.NextTeleport then
		activator:SetPos(impulse.Config.MBEntrance)
		self.NextTP = CurTime() + 1.5
		activator.NextTeleport = CurTime() + 10
	end
end