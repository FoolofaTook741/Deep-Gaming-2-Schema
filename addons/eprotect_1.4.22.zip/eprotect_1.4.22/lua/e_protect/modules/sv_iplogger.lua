local function handleIPLoggin(ply, ip)
    local sid64 = ply:SteamID64()
    http.Fetch("http://ip-api.com/json/"..ip, function(json)
        json = util.JSONToTable(json)
        local result = json["countryCode"]

        if !result then result = "N/A" end

        eProtect.registerIP(sid64, ip, result)
    end, function()
        eProtect.registerIP(sid64, ip, "N/A")
    end)
end

hook.Add("PlayerInitialSpawn", "eP:IPLogging", function(ply)
    if ply:IsBot() or eProtect.config["disabledModules"]["identifier"] then return end
    local plyIP = ply:IPAddress()
    local ip = string.sub(plyIP, 1, string.find(plyIP, ":") - 1)

    handleIPLoggin(ply, ip)
end)